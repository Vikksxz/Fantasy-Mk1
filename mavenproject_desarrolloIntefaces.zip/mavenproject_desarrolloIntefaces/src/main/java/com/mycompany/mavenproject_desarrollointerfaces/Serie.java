/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject_desarrollointerfaces;

import java.util.Arrays;

/**
 * <p>Representa una Serie de contenido multimedia, heredando de {@link Titulo} e implementando {@link Identificable}.</p>
 * <p>Contiene información sobre temporadas, capítulos y duración de episodios.</p>
 */
public class Serie extends Titulo implements Identificable {
    
    /** Número total de temporadas de la serie. */
    private int temporadas;
    /** Array que almacena el número de capítulos por cada temporada. */
    private int[] capitulosPorTemporada;
    /** Array que almacena la duración (en minutos) de los episodios. */
    private int[] duracionCapitulo;
    /** Ruta del archivo de imagen (poster) de la serie. (DÍA 5) */
    private String rutaImagen;
    
    /**
     * Constructor para crear un objeto Serie.
     * * @param id Identificador único de la serie.
     * @param nombre Nombre de la serie.
     * @param temporadas Número de temporadas que tiene la serie.
     * @param caps Array con el número de capítulos por temporada.
     * @param duraciones Array con la duración de los capítulos (en minutos).
     * @param rutaImagen Ruta de la imagen/poster de la serie.
     */
    public Serie(int id, String nombre, int temporadas, int[] caps, int[] duraciones, String rutaImagen) {
        super(id, nombre);
        this.temporadas = temporadas;
        this.capitulosPorTemporada = caps;
        this.duracionCapitulo = duraciones;
        this.rutaImagen = rutaImagen;
    }
    
    /**
     * Suma la duración total de todos los capítulos de la serie.
     * * @return La duración total de la serie en minutos.
     */
    public int duracionTotal(){
        int total = 0;
        for (int d : duracionCapitulo) {
            total += d;
        }
        return total;
    }
    
    /**
     * Muestra por pantalla todos los atributos de la serie, incluyendo los heredados de {@link Titulo}.
     */
    public void mostrarDatos(){
        System.out.println("--- Datos de la Serie ---");
        System.out.println("ID: " + id);
        System.out.println("Nombre: " + nombre);
        System.out.println("Temporadas: " + temporadas);
        System.out.println("Capítulos por Temporada: " + Arrays.toString(capitulosPorTemporada));
        System.out.println("Duración de Capítulos (min): " + Arrays.toString(duracionCapitulo));
        System.out.println("Duración Total (min): " + duracionTotal());
        System.out.println("Ruta de Imagen: " + rutaImagen);
    }
    

    public int getTemporadas() {
        return temporadas;
    }

    public int[] getCapitulosPorTemporada() {
        return capitulosPorTemporada;
    }

    public int[] getDuracionCapitulo() {
        return duracionCapitulo;
    }
    
    public String getRutaImagen() {
        return rutaImagen;
    }

    public void setRutaImagen(String rutaImagen) {
        this.rutaImagen = rutaImagen;
    }
}

