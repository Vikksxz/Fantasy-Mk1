/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject_desarrollointerfaces;

import javax.swing.*;
import java.awt.FlowLayout;

/**
 * <p>JFrame inicial que permite al usuario iniciar sesión con un usuario y contraseña.</p>
 * <p>Tras la autenticación, abre el {@link SelectorFrame}.</p>
 */
public class LoginFrame extends JFrame{
    
    /**
     * Constructor para crear el frame de Login.
     */
    public LoginFrame(){
        setTitle("Login");
        setSize(300, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        setLocationRelativeTo(null);
        
        JLabel userLbl = new JLabel("Usuario:");
        JTextField usuarioTxt = new JTextField(15);
        
        JLabel passLbl = new JLabel("Contraseña:");
        JPasswordField passPwd = new JPasswordField(15);
        passPwd.setText("");
        
        BotonPersonalizado boton = new BotonPersonalizado("Entrar");
        
        
        JPanel userPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        userPanel.add(userLbl);
        userPanel.add(usuarioTxt);
        
        JPanel passPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        passPanel.add(passLbl);
        passPanel.add(passPwd);
        
        add(userPanel);
        add(passPanel);
        add(boton);
        
        boton.addActionListener (e -> {
            
            if (usuarioTxt.getText().equals("admin") && String.valueOf(passPwd.getPassword()).equals("1234")) {
                new SelectorFrame().setVisible(true);
                this.setVisible(false); // Ocultar el LoginFrame
            } else {
                JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos.", "Error de Login", JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}
