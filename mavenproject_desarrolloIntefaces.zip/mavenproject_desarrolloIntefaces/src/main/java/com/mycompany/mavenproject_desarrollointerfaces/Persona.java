/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject_desarrollointerfaces;

/**
 * <p>Clase base que representa una Persona, con atributos básicos como nombre e edad.</p>
 * <p>Las clases {@link Cliente} y {@link Actor} heredan de esta clase.</p>
 */
public class Persona {
    /** El identificador único de la persona. */
    protected int id;
    /** El nombre de la persona. */
    protected String nombre;
    /** La edad de la persona. */
    protected int edad;
    
    /**
     * Crea una nueva persona con su ID, nombre y edad.
     * * @param id Identificador único de la persona.
     * @param nombre Nombre de la persona.
     * @param edad Edad de la persona.
     */
    public Persona(int id,String nombre, int edad) {
        this.id = id;
        this.nombre = nombre;
        this.edad = edad;
    }

    /**
     * Devuelve el identificador de la persona.
     * @return El ID de la persona.
     */
    public int getId() {
        return id;
    }
    
    /**
     * Establece el identificador de la persona.
     * @param id El nuevo ID de la persona.
     */
    public void setId(int id) {
        this.id = id;
    }
    
    /**
     * Devuelve el nombre de la persona.
     * * @return Nombre de la persona.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establece el nombre de la persona.
     * * @param nombre El nuevo nombre de la persona.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Devuelve la edad de la persona.
     * * @return La edad de la persona.
     */
    public int getEdad() {
        return edad;
    }

    /**
     * Establece la edad de la persona.
     * * @param edad La nueva edad de la persona.
     */
    public void setEdad(int edad) {
        this.edad = edad;
    }
}
