/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.mycompany.mavenproject_desarrollointerfaces;

/**
 *<p>Lista de tipos de cliente</p>
 * <p>Los tipos son: ANUNCIOS, BASICO, PREMiUM</p>
 * @author george
 */
public enum TipoCliente {
    /**Suscripcion con anuncios. */
    ANUNCIOS,
    /**Pago basico */
    BASICO,
    /**Pago premium, todos los beneficios. */
    PREMIUM
}
