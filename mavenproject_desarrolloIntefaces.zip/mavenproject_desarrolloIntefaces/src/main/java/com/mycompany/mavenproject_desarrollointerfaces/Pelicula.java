/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject_desarrollointerfaces;

/**
 * <p>Representa una Película de contenido multimedia, heredando de {@link Titulo} e implementando {@link Identificable}.</p>
 * <p>Contiene la duración total de la película.</p>
 */
public class Pelicula extends Titulo implements Identificable {
    /** La duración total de la película en minutos. */
    private int duracion;
    
    /** Ruta del archivo de imagen (poster) de la película. (DÍA 5) */
    private String rutaImagen;
    
    
    /**
     * Constructor para crear un objeto Pelicula.
     * @param id Id de la pelicula.
     * @param nombre Nombre de la pelicula.
     * @param duracion Duracion de la pelicula en minutos.
     * @param rutaImagen Ruta de la imagen/poster de la película.
     */
    public Pelicula(int id, String nombre, int duracion, String rutaImagen) {
        super(id, nombre);
        this.duracion = duracion;
        this.rutaImagen = rutaImagen;
    }

    /**
     * Muestra por pantalla todos los atributos de la película, incluyendo los heredados de {@link Titulo}.
     */
    public void mostrarDatos(){
        System.out.println("--- Datos de la Película ---");
        System.out.println("ID: " + id);
        System.out.println("Nombre: " + nombre);
        System.out.println("Duración (min): " + duracion);
        System.out.println("Ruta de Imagen: " + rutaImagen);
    }
    
    
    public int getDuracion() {
        return duracion;
    }
    
    public String getRutaImagen() {
        return rutaImagen;
    }

    public void setRutaImagen(String rutaImagen) {
        this.rutaImagen = rutaImagen;
    }
}
