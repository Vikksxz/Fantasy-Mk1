/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject_desarrollointerfaces;

/**
 * <p>Representa un Actor, heredando de {@link Persona} e implementando {@link Identificable}.</p>
 * <p>Actualmente no añade atributos propios, solo hereda de Persona.</p>
 */
public class Actor extends Persona implements Identificable {
      /**
       * Constructor para crear un objeto Actor.
       * @param id Identificador único del actor.
       * @param nombre Nombre del actor.
       * @param edad Edad del actor.
       */
      public Actor(int id, String nombre, int edad) {
          super(id, nombre, edad);
      }
      
      /**
       * Muestra por pantalla todos los atributos del actor, incluyendo los heredados de {@link Persona}.
       */
      public void mostrarDatos(){
          System.out.println("--- Datos del Actor ---");
          System.out.println("ID: " + id);
          System.out.println("Nombre: " + nombre);
          System.out.println("Edad: " + edad);
      }
}
