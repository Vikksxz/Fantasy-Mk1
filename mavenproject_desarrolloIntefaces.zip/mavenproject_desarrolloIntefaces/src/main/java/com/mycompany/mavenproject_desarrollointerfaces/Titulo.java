/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject_desarrollointerfaces;

/**
 * <p>Clase base que representa un Título de contenido multimedia.</p>
 * <p>Las clases {@link Serie} y {@link Pelicula} heredan de esta clase.</p>
 */
public class Titulo {
    /** El identificador único del título. */
    protected int id;
    /** El nombre del título. */
    protected String nombre;

    /**
     * Constructor para crear un objeto Titulo.
     * @param id Identificador único del título.
     * @param nombre Nombre del título.
     */
    public Titulo(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    /**
     * Obtiene el identificador único del título.
     * @return El ID del título.
     */
    public int getId() {
        return id;
    }

    /**
     * Establece el identificador único del título.
     * @param id El nuevo ID del título.
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Obtiene el nombre del título.
     * @return El nombre del título.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establece el nombre del título.
     * @param nombre El nuevo nombre del título.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
