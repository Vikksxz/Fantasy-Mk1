/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject_desarrollointerfaces;

import java.awt.GridLayout;
import javax.swing.*;

/**
 * <p>JFrame de selección que permite al usuario elegir entre el catálogo de 
 * {@link PeliculasFrame} o {@link SeriesFrame}.</p>
 * <p>Se abre tras el inicio de sesión exitoso.</p>
 */
public class SelectorFrame extends JFrame {
    
    /**
     * Constructor para crear el frame de selección.
     */
    public SelectorFrame(){
        setTitle("Seleccionar Contenido");
        setSize(300, 200);
        
        setLayout(new GridLayout(2, 1, 10, 10)); 
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en la pantalla
        
        BotonPersonalizado pelisBtn = new BotonPersonalizado("Películas");
        BotonPersonalizado seriesBtn = new BotonPersonalizado("Series");
        
        
        pelisBtn.addActionListener(e -> {
            new PeliculasFrame().setVisible(true);
            this.dispose(); // Cerrar el SelectorFrame (DÍA 4)
        });
        
        
        seriesBtn.addActionListener(e -> {
            new SeriesFrame().setVisible(true);
            this.dispose();
        });
        
        
        add(pelisBtn);
        add(seriesBtn);
    }
}
