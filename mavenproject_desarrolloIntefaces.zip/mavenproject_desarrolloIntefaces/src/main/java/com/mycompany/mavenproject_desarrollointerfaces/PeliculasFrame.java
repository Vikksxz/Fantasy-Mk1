/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject_desarrollointerfaces;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout; 
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * <p>JFrame que muestra la lista de películas y sus detalles al seleccionarlas.</p>
 * <p>Esta pantalla se abre al seleccionar 'Películas' en el {@link SelectorFrame}.</p>
 */
public class PeliculasFrame extends JFrame {
    
    /**
     * Constructor para crear el frame de Películas.
     */
    public PeliculasFrame() {
        setTitle("Catálogo de Películas");
        setSize(700, 500);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);
        
        JLabel tituloLbl = new JLabel("PELÍCULAS", SwingConstants.CENTER);
        tituloLbl.setFont(tituloLbl.getFont().deriveFont(20f));
        add(tituloLbl, BorderLayout.NORTH);
        
        
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
       
        String[] nombresPeliculas;
        
      
        final boolean hayDatosReales = Main.peliculas != null && !Main.peliculas.isEmpty();
        
        if (hayDatosReales) {
            
             nombresPeliculas = Main.peliculas.stream().map(Titulo::getNombre).toArray(String[]::new);
        } else {
             
             nombresPeliculas = new String[]{"Pelicula 1 (Sin datos)", "Pelicula 2 (Sin datos)", "Pelicula 3 (Sin datos)"};
        }
        
        
        final JList<String> listaPeliculas = new JList<>(nombresPeliculas);
        JScrollPane scrollPane = new JScrollPane(listaPeliculas);
        scrollPane.setPreferredSize(new Dimension(200, 400));
        
        
        JPanel detallePanel = new JPanel(new BorderLayout(5, 5));
        detallePanel.setBorder(BorderFactory.createTitledBorder("Detalles de la Película"));
        
       
        final JLabel imagenLbl = new JLabel("Seleccione una película", SwingConstants.CENTER);
      
        final JTextArea infoArea = new JTextArea(10, 40);
        infoArea.setEditable(false);
        infoArea.setWrapStyleWord(true);
        infoArea.setLineWrap(true);
        
        detallePanel.add(imagenLbl, BorderLayout.NORTH);
        detallePanel.add(new JScrollPane(infoArea), BorderLayout.CENTER);
        
        
        listaPeliculas.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int index = listaPeliculas.getSelectedIndex();
                
                if (index != -1 && hayDatosReales) {
                    
                    Pelicula p = (Pelicula) Main.peliculas.get(index);
                    
                    
                    try {
                     
                        ImageIcon icon = new ImageIcon(p.getRutaImagen());
                        
                        
                        if (icon.getIconWidth() > 300) {
                            icon = new ImageIcon(icon.getImage().getScaledInstance(300, -1, java.awt.Image.SCALE_SMOOTH));
                        }
                        imagenLbl.setIcon(icon);
                        imagenLbl.setText("");
                    } catch (Exception ex) {
                        imagenLbl.setIcon(null);
                        imagenLbl.setText("No hay imagen (" + p.getRutaImagen() + ")");
                        
                    }
                    
                    
                    
                    infoArea.setText(
                        "ID: " + p.getId() + "\n" +
                        "Nombre: " + p.getNombre() + "\n" +
                        "Duración (min): " + p.getDuracion() + "\n" +
                        "Ruta de Imagen: " + p.getRutaImagen()
                    );
                } else if (index != -1) {
                     
                     infoArea.setText("Detalles no disponibles para " + listaPeliculas.getSelectedValue());
                     imagenLbl.setIcon(null);
                     imagenLbl.setText("No hay datos de película");
                }
            }
        });
        
        
       
        JPanel favoritosPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 5));
        
        
        final BotonPersonalizado botonVolver = new BotonPersonalizado("Volver a Categorías");
        favoritosPanel.add(botonVolver);
        
        
        botonVolver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                setVisible(false);
               
                new SelectorFrame().setVisible(true);
            
                dispose();
            }
        });

        final BotonPersonalizado favoritosBtn = new BotonPersonalizado("Guardar como Favorita");
        favoritosBtn.addActionListener(e -> guardarFavoritos(listaPeliculas.getSelectedValue()));
        favoritosPanel.add(favoritosBtn);

        mainPanel.add(scrollPane, BorderLayout.WEST);
        mainPanel.add(detallePanel, BorderLayout.CENTER);
        mainPanel.add(favoritosPanel, BorderLayout.SOUTH);
        
        add(mainPanel, BorderLayout.CENTER);
        
        setVisible(true);
    }
    
    /**
     * Función que guarda el título seleccionado como favorito. (Simulado)
     * @param titulo El nombre de la película a guardar como favorita.
     */
    private void guardarFavoritos(String titulo) {
        if (titulo != null && !titulo.contains("(Sin datos)")) {
            JOptionPane.showMessageDialog(this, "Película '" + titulo + "' guardada en favoritos. (Simulado)");
        } else {
            JOptionPane.showMessageDialog(this, "Debe seleccionar una película primero.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
