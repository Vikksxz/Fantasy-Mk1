/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject_desarrollointerfaces;

import javax.swing.JButton;
import java.awt.Color;
import java.awt.Font;

/**
 * <p>Componente que hereda de {@link javax.swing.JButton}.</p>
 * <p>Actúa como el botón predefinido del sistema, configurando
 * por defecto un color de fondo negro y letra blanca.</p>
 */
public class BotonPersonalizado extends JButton {
    
    /**
     * Constructor para crear un BotonPersonalizado.
     * * @param texto El texto que se mostrará en el botón.
     */
    public BotonPersonalizado(String texto){
        super(texto);
        
        setBackground(Color.decode("#333333"));
        setForeground(Color.WHITE);
        setFocusPainted(false);
        setFont(new Font("Arial", Font.BOLD, 14));
    }
}
