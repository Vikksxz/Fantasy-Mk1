/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject_desarrollointerfaces;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import javax.swing.SwingUtilities;

/**
 * <p>Clase principal del proyecto. Contiene la lógica inicial para la creación
 * de objetos y la ejecución de la aplicación GUI (DÍA 4).</p>
 */
public class Main {
    
    /** Lista estática para almacenar todos los objetos {@link Serie}. (DÍA 5) */
    public static List<Serie> series = new ArrayList<>();
    /** Lista estática para almacenar todos los objetos {@link Pelicula}. (DÍA 5) */
    public static List<Pelicula> peliculas = new ArrayList<>();
    
    /**
     * El método principal que inicia la aplicación.
     * @param args Argumentos de la línea de comandos (no utilizados).
     */
    public static void main(String[] args) {
       
        crearObjetosIniciales(); 
        
        
        SwingUtilities.invokeLater(() -> {
            new LoginFrame().setVisible(true);
        });
    }
    
    /**
     * Crea y almacena varios objetos de las clases {@link Serie}, {@link Pelicula}, 
     * {@link Cliente} y {@link Actor}. Este método es llamado al iniciar el programa. (DÍA 2)
     */
    public static void crearObjetosIniciales() {
        
        series.add(new Serie(1, "The Great Developer", 4, new int[]{10, 8, 12, 10}, new int[]{50, 48, 55, 45}, "img/great_developer.jpg"));
        series.add(new Serie(2, "Java Titans", 2, new int[]{6, 6}, new int[]{60, 60}, "img/java_titans.jpg"));
        
        
        peliculas.add(new Pelicula(101, "Code Runner", 120, "img/code_runner.jpg"));
        peliculas.add(new Pelicula(102, "The Matrix Reloaded", 138, "img/matrix_reloaded.jpg"));
        
        
        Cliente cliente1 = new Cliente(1001, "Ana Garcia", 28, TipoCliente.PREMIUM);
        Cliente cliente2 = new Cliente(1002, "Luis Perez", 45, TipoCliente.ANUNCIOS);
        
        
        Actor actor1 = new Actor(2001, "John Smith", 35);
        
        System.out.println("Objetos iniciales creados y cargados.");
        
        
        System.out.println("\n--- Ejemplos de Salida de Consola ---");
        cliente1.mostrarID(cliente1.getId());
        cliente1.mostrarDatos();
        
        series.get(0).mostrarID(series.get(0).getId());
        series.get(0).mostrarDatos();
        System.out.println("Duración Total de " + series.get(0).getNombre() + ": " + series.get(0).duracionTotal() + " minutos.");
        System.out.println("-------------------------------------\n");
    }
    
    /**
     * Pide al usuario por consola si desea ver información de una Serie o Película
     * y la muestra por pantalla. (Método de prueba de consola, DÍA 2)
     */
    public static void pedirInformacionYMostrar() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("¿Qué tipo de información desea ver? (1: Serie, 2: Película)");
        try {
            int opcion = scanner.nextInt();
            
            switch (opcion) {
                case 1:
                    System.out.println("Mostrando datos de la primera serie:");
                    series.get(0).mostrarDatos();
                    break;
                case 2:
                    System.out.println("Mostrando datos de la primera película:");
                    peliculas.get(0).mostrarDatos();
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        } catch (InputMismatchException | IndexOutOfBoundsException e) {
            System.out.println("Error: Entrada no válida o índice fuera de rango.");
        } 
    }
}