package com.mycompany.mavenproject_desarrollointerfaces;

/**
 * <p>Interfaz funcional para entidades que tienen un identificador único (ID).</p>
 * <p>Proporciona un método default para mostrar dicho ID por consola.</p>
 */
public interface Identificable {
    
    /**
     * Muestra por pantalla el ID de la entidad que implementa esta interfaz.
     * @param id El identificador único a mostrar.
     */
    default void mostrarID(int id) {
        System.out.println("--- Identificador ---");
        System.out.println("ID: " + id);
    }
}
