/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject_desarrollointerfaces;

/**
 * <p>Representa un Cliente, heredando de {@link Persona} e implementando {@link Identificable}.</p>
 * <p>Contiene el tipo de suscripción del cliente.</p>
 */
public class Cliente extends Persona implements Identificable {
    /** El tipo de suscripción del cliente: {@link TipoCliente#ANUNCIOS}, {@link TipoCliente#BASICO} o {@link TipoCliente#PREMIUM}. */
    private TipoCliente tipo;
    
    /**
     * Constructor para crear un objeto Cliente.
     * * @param id identificador de cliente.
     * @param nombre nombre del cliente.
     * @param edad edad del cliente.
     * @param tipo tipo del cliente (suscripción).
     */
    public Cliente(int id, String nombre, int edad, TipoCliente tipo) {
        super(id, nombre, edad);
        this.tipo = tipo;
    }
    
    /**
     * Muestra por pantalla todos los atributos del cliente, incluyendo los heredados de {@link Persona}.
     */
    public void mostrarDatos(){
        System.out.println("--- Datos del Cliente ---");
        System.out.println("ID: " + id);
        System.out.println("Nombre: " + nombre);
        System.out.println("Edad: " + edad);
        System.out.println("Tipo de Cliente: " + tipo);
    }
}

