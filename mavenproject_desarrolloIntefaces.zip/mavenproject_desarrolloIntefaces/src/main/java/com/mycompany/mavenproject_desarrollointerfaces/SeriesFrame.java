/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject_desarrollointerfaces;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout; // Necesario para gestionar los botones inferiores
import java.util.Arrays;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import java.awt.event.ActionEvent; // Necesario para ActionListener
import java.awt.event.ActionListener; // Necesario para la acción del botón

/**
 * <p>JFrame que muestra la lista de series y sus detalles al seleccionarlas.</p>
 * <p>Esta pantalla se abre al seleccionar 'Series' en el {@link SelectorFrame}.</p>
 */
public class SeriesFrame extends JFrame {
    
    /**
     * Constructor para crear el frame de Series.
     */
    public SeriesFrame() {
        setTitle("Catálogo de Series");
        setSize(700, 500);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);
        
        JLabel tituloLbl = new JLabel("SERIES", SwingConstants.CENTER);
        tituloLbl.setFont(tituloLbl.getFont().deriveFont(20f));
        add(tituloLbl, BorderLayout.NORTH);
        
        
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        
        String[] nombresSeries;
        
        
        final boolean hayDatosReales = Main.series != null && !Main.series.isEmpty();
        
        if (hayDatosReales) {
             
             nombresSeries = Main.series.stream().map(Titulo::getNombre).toArray(String[]::new);
        } else {
            
             nombresSeries = new String[]{"Serie A (Sin datos)", "Serie B (Sin datos)"};
        }
    
        
       
        final JList<String> listaSeries = new JList<>(nombresSeries);
        JScrollPane scrollPane = new JScrollPane(listaSeries);
        scrollPane.setPreferredSize(new Dimension(200, 400));
        
        
        JPanel detallePanel = new JPanel(new BorderLayout(5, 5));
        detallePanel.setBorder(BorderFactory.createTitledBorder("Detalles de la Serie"));
        
        
        final JLabel imagenLbl = new JLabel("Seleccione una serie", SwingConstants.CENTER);
        
        final JTextArea infoArea = new JTextArea(10, 40);
        infoArea.setEditable(false);
        infoArea.setWrapStyleWord(true);
        infoArea.setLineWrap(true);
        
        detallePanel.add(imagenLbl, BorderLayout.NORTH);
        detallePanel.add(new JScrollPane(infoArea), BorderLayout.CENTER);
        
        
        listaSeries.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int index = listaSeries.getSelectedIndex();
                
              
                if (index != -1 && hayDatosReales) {
                    
                    Serie s = (Serie) Main.series.get(index);
                    
                    
                    try {
                       
                        ImageIcon icon = new ImageIcon(s.getRutaImagen());
                        
                        
                        if (icon.getIconWidth() > 300) {
                            icon = new ImageIcon(icon.getImage().getScaledInstance(300, -1, java.awt.Image.SCALE_SMOOTH));
                        }
                        imagenLbl.setIcon(icon);
                        imagenLbl.setText("");
                    } catch (Exception ex) {
                        imagenLbl.setIcon(null);
                        imagenLbl.setText("No hay imagen (" + s.getRutaImagen() + ")");
                       
                    }
                    
                    
                    infoArea.setText(
                        "ID: " + s.getId() + "\n" +
                        "Nombre: " + s.getNombre() + "\n" +
                        "Temporadas: " + s.getTemporadas() + "\n" +
                        "Capítulos por Temp.: " + Arrays.toString(s.getCapitulosPorTemporada()) + "\n" +
                        "Duración Capítulos (min): " + Arrays.toString(s.getDuracionCapitulo()) + "\n" +
                        "Duración Total (min): " + s.duracionTotal() + "\n" +
                        "Ruta de Imagen: " + s.getRutaImagen()
                    );
                } else if (index != -1) {
                     // Caso donde se selecciona un item pero no hay datos reales (simulación)
                     infoArea.setText("Detalles no disponibles para " + listaSeries.getSelectedValue());
                     imagenLbl.setIcon(null);
                     imagenLbl.setText("No hay datos de serie");
                }
            }
        });
        
        
        
        JPanel favoritosPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 5));
        
        
        final BotonPersonalizado botonVolver = new BotonPersonalizado("Volver a Categorías");
        favoritosPanel.add(botonVolver);
        
        
        botonVolver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Oculta la ventana actual (SeriesFrame)
                setVisible(false);
                // Muestra el SelectorFrame
                // Asumo que SelectorFrame existe y tiene un constructor sin argumentos
                new SelectorFrame().setVisible(true);
                // Libera recursos de la ventana actual
                dispose();
            }
        });
      

        
        final BotonPersonalizado favoritosBtn = new BotonPersonalizado("Guardar como Favorita");
        favoritosBtn.addActionListener(e -> guardarFavoritos(listaSeries.getSelectedValue()));
        favoritosPanel.add(favoritosBtn);

        mainPanel.add(scrollPane, BorderLayout.WEST);
        mainPanel.add(detallePanel, BorderLayout.CENTER);
        mainPanel.add(favoritosPanel, BorderLayout.SOUTH);
        
        add(mainPanel, BorderLayout.CENTER);
        
        setVisible(true);
    }
    
    /**
     * Función que guarda el título seleccionado como favorito. (DÍA 6)
     * @param titulo El nombre de la serie a guardar como favorita.
     */
    private void guardarFavoritos(String titulo) {
        if (titulo != null && !titulo.contains("(Sin datos)")) { // Ajuste del texto a "Sin datos"
            JOptionPane.showMessageDialog(this, "Serie '" + titulo + "' guardada en favoritos. (Simulado)");
        } else {
            JOptionPane.showMessageDialog(this, "Debe seleccionar una serie primero.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}