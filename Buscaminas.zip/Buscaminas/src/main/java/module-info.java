module com.mycompany.buscaminas {

    requires javafx.controls;
    requires javafx.fxml;

    opens com.mycompany.buscaminas.controller to javafx.fxml;

    exports com.mycompany.buscaminas.app;
}

