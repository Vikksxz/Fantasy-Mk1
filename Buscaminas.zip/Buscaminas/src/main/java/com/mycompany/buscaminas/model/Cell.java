package com.mycompany.buscaminas.model;

public class Cell{
    public boolean mine;
    public boolean revealed;
    public boolean flagged;
    public int adjacent;
}