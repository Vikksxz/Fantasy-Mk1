package com.mycompany.buscaminas.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import com.mycompany.buscaminas.util.SceneManager;

public class EndController {
    @FXML private Label resultLabel;
    
    public void setResult(boolean victory) {
        if (victory) {
            resultLabel.setText("Done Donete gud!");
            resultLabel.setStyle("-fx-text-fill: #03DAC6; -fx-font-weight: bold;");
        } else {
            resultLabel.setText("Parguela UwU");
            resultLabel.setStyle("-fx-text-fill: #CF6679; -fx-font-weight: bold;");
        }
    }
    
    @FXML
    private void backMenu(){
        SceneManager.loadMenu();
    }
}