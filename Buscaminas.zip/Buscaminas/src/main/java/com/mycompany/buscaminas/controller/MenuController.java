package com.mycompany.buscaminas.controller;

import com.mycompany.buscaminas.model.GameDifficulty;
import com.mycompany.buscaminas.util.SceneManager;
import javafx.fxml.FXML;
import javafx.scene.layout.VBox;

public class MenuController {

    /* =====================
       TARJETAS DE DIFICULTAD
       ===================== */
    @FXML private VBox easyCard;
    @FXML private VBox normalCard;
    @FXML private VBox hardCard;

    /* =====================
       ESTADO
       ===================== */
    private GameDifficulty selectedDifficulty;

    /* =====================
       INIT
       ===================== */
    @FXML
    public void initialize() {
        selectEasy(); // dificultad por defecto
    }

    /* =====================
       SELECCIÓN DE TARJETAS
       ===================== */
    @FXML
    private void selectEasy() {
        selectedDifficulty = GameDifficulty.EASY;
        selectCard(easyCard);
    }

    @FXML
    private void selectNormal() {
        selectedDifficulty = GameDifficulty.NORMAL;
        selectCard(normalCard);
    }

    @FXML
    private void selectHard() {
        selectedDifficulty = GameDifficulty.HARD;
        selectCard(hardCard);
    }

    private void selectCard(VBox selected) {
        easyCard.getStyleClass().remove("difficulty-card-selected");
        normalCard.getStyleClass().remove("difficulty-card-selected");
        hardCard.getStyleClass().remove("difficulty-card-selected");

        selected.getStyleClass().add("difficulty-card-selected");
    }

    /* =====================
       BOTONES
       ===================== */
    @FXML
    private void startGame() {
        SceneManager.loadGame(
            selectedDifficulty.getRows(),
            selectedDifficulty.getCols(),
            selectedDifficulty.getMines()
        );
    }

    @FXML
    private void exit() {
        System.exit(0);
    }
}
