package com.mycompany.buscaminas.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.GridPane;
import javafx.animation.ScaleTransition;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.util.Duration;
import com.mycompany.buscaminas.model.*;
import com.mycompany.buscaminas.util.SceneManager;

public class GameController {
    @FXML private GridPane grid;
    @FXML private Label timerLabel; // Sincronizado con game.fxml [cite: 2]
    @FXML private Label minesLabel; // Sincronizado con game.fxml [cite: 1]
    
    private Board board;
    private Button[][] buttons;
    private int revealedCount = 0;
    private int seconds = 0;
    private Timeline timer;
    private int flagsPlaced = 0;

    public void init(GameDifficulty diff) {

    int rows = diff.getRows();
    int cols = diff.getCols();
    int mines = diff.getMines();

    board = new Board(rows, cols, mines);
    buttons = new Button[rows][cols];
    grid.getChildren().clear();

    setupTimer();
    minesLabel.setText("🚩 " + mines);

    for (int r = 0; r < rows; r++) {
        for (int c = 0; c < cols; c++) {

            Button btn = new Button();
            btn.setPrefSize(40, 40);
            btn.getStyleClass().add("button-cell");
            buttons[r][c] = btn;

            final int row = r, col = c;
            btn.setOnMouseClicked(e -> {
                if (e.getButton() == MouseButton.PRIMARY) reveal(row, col);
                else if (e.getButton() == MouseButton.SECONDARY) toggleFlag(row, col);
            });

            grid.add(btn, c, r);
            animateEntrance(btn, (r + c) * 10); // Toque Pro
        }
    }
}


    private void setupTimer() {
        timer = new Timeline(new KeyFrame(Duration.seconds(1), e -> {
            seconds++;
            timerLabel.setText("⏱ " + seconds + "s");
        }));
        timer.setCycleCount(Timeline.INDEFINITE);
        timer.play();
    }

    private void animateEntrance(Button btn, int delayMs) {
        ScaleTransition st = new ScaleTransition(Duration.millis(300), btn);
        st.setFromX(0); st.setFromY(0);
        st.setToX(1); st.setToY(1);
        st.setDelay(Duration.millis(delayMs));
        st.play();
    }

    private void reveal(int r, int c) {
    Cell cell = board.cells[r][c];
    Button btn = buttons[r][c];
    
    if (cell.revealed || cell.flagged) return;
    
    cell.revealed = true;
    revealedCount++;
    
    // Aplicamos la clase de celda revelada
    btn.getStyleClass().add("button-cell-revealed");
    btn.setDisable(true);
    btn.setOpacity(1.0); // Para que el texto no se vea gris al desactivar
    
    if (cell.mine) {
        btn.setText("💣");
        btn.setStyle("-fx-background-color: #CF6679;");
        endGame(false);
        return;
    }

    if (cell.adjacent > 0) {
        btn.setText(String.valueOf(cell.adjacent));
        
        // ESTA ES LA LÍNEA CLAVE:
        // Añade la clase adj-1, adj-2, etc., según el valor
        btn.getStyleClass().add("adj-" + cell.adjacent);
        
    } else {
        // Lógica de expansión para celdas vacías (recursividad)
        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
                int nr = r + i, nc = c + j;
                if (nr >= 0 && nr < board.rows && nc >= 0 && nc < board.cols) {
                    reveal(nr, nc);
                }
            }
        }
    }
    checkVictory();
}
    
    public void initManual(int rows, int cols, int mines) {
    this.board = new Board(rows, cols, mines);
    this.buttons = new Button[rows][cols];
    
    grid.getChildren().clear();
    
    // Configuramos el HUD
    minesLabel.setText("🚩 " + mines);
    setupTimer();

    for (int r = 0; r < rows; r++) {
        for (int c = 0; c < cols; c++) {
            Button btn = new Button();
            
            // Tamaño fijo para evitar deformaciones
            btn.setMinWidth(35);
            btn.setMaxWidth(35);
            btn.setMinHeight(35);
            btn.setMaxHeight(35);
            
            btn.getStyleClass().add("button-cell");
            buttons[r][c] = btn;

            final int row = r, col = c;
            btn.setOnMouseClicked(e -> {
                if (e.getButton() == MouseButton.PRIMARY) reveal(row, col);
                else if (e.getButton() == MouseButton.SECONDARY) toggleFlag(row, col);
            });

            grid.add(btn, c, r);
        }
    }
}

    private void toggleFlag(int r, int c) {
        Cell cell = board.cells[r][c];
        if (cell.revealed) return;
        cell.flagged = !cell.flagged;
        buttons[r][c].setText(cell.flagged ? "🚩" : "");
        flagsPlaced += cell.flagged ? 1 : -1;
        minesLabel.setText("🚩 " + (board.mines - flagsPlaced));
    }

    private void checkVictory() {
        if (revealedCount == (board.rows * board.cols) - board.mines) endGame(true);
    }

    private void endGame(boolean victory) {
        if(timer != null) timer.stop();
        SceneManager.loadEnd(victory);
    }

    @FXML private void backMenu() { 
        if(timer != null) timer.stop();
        SceneManager.loadMenu(); 
    }
}