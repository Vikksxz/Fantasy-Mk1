package com.mycompany.buscaminas.model;

import java.util.Random;

public class Board{
    public Cell[][] cells;
    public int rows, cols, mines;
    
    
    public Board(int r, int c, int m){
        rows = r;
        cols = c;
        mines = m;
        cells = new Cell[r][c];
        
        for (int i = 0; i < r; i++){
            for (int j = 0; j < c; j++){
                cells[i][j] = new Cell();
            }
        }
        placeMines();
        calculateAdjacents();
    }
    
    private void placeMines(){
        Random rnd = new Random();
        int placed = 0;
        
        while (placed < mines) {
            int r = rnd.nextInt(rows);
            int c = rnd.nextInt(cols);
            if(!cells[r][c].mine){
                cells[r][c].mine = true;
                placed++;
            }
        }
    }
    
    private void calculateAdjacents(){
        for(int r = 0; r < rows; r++){
            for (int c = 0; c < cols; c++){
                if (!cells[r][c].mine){
                    cells[r][c].adjacent = countMines(r, c);
                }
            }
        } 
    }
    private int countMines(int r, int c){
        int count = 0;
        for (int i = -1; i <= 1; i++){
            for (int j = -1; j <= 1; j++){
                int nr = r + i, nc = c + j;
                if (nr >= 0 && nr < rows && nc >= 0 && nc < cols){
                    if(cells[nr][nc].mine){
                        count++;
                    }
                }
            }
        }
        return count;
    }
}