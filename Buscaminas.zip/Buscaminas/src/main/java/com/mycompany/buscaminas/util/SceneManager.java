package com.mycompany.buscaminas.util;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import com.mycompany.buscaminas.controller.EndController;
import com.mycompany.buscaminas.controller.GameController;
import javafx.scene.Parent;

public class SceneManager{
    private static Stage stage;
    
    public static void setStage(Stage s){
        stage = s;
    }
    
    public static void loadMenu() {
        try {
            Parent root = FXMLLoader.load(
                SceneManager.class.getResource("/view/menu.fxml")
            );

            Scene scene = new Scene(root, 700, 700);
            stage.setScene(scene);

            stage.setResizable(false); // IMPORTANTE
            stage.centerOnScreen();
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static void loadGame(int rows, int cols, int mines) {
    try {
        FXMLLoader loader = new FXMLLoader(SceneManager.class.getResource("/view/game.fxml"));
        Parent root = loader.load(); // 1. Cargamos el esqueleto

        // 2. Obtenemos el controlador ANTES de mostrar la escena
        GameController controller = loader.getController();
        
        // 3. Importante: Ejecutamos la lógica que CREA los botones
        controller.initManual(rows, cols, mines); 

        Scene scene = new Scene(root);
        stage.setScene(scene);

        // 4. TRUCO DE REDIMENSIÓN:
        stage.setResizable(true); 
        stage.sizeToScene();  // Calcula el tamaño basado en los botones creados
        stage.centerOnScreen(); // Recentra la ventana ya redimensionada
        stage.show();

    } catch (Exception e) {
        e.printStackTrace();
    }
}  
    public static void loadEnd(boolean victory) {
        try {
            FXMLLoader loader = new FXMLLoader(SceneManager.class.getResource("/view/end.fxml"));
            Scene scene = new Scene(loader.load());
            EndController controller = loader.getController();
            controller.setResult(victory);
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private static void loadScene(String path) {
        try {
            stage.setScene(new Scene(
                        FXMLLoader.load(SceneManager.class.getResource(path))));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}