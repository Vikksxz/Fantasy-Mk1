/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.calculadora_jemmy;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

/**
 *
 * @author george
 */

public class Calculadora_Jemmy extends JFrame {
    private JTextField display;
    private double resultado;
    private String operacion = "";
    private boolean nuevaOperacion = true;
    
    public Calculadora_Jemmy() {
    setTitle("Calculadora");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLayout(new BorderLayout());

    display = new JTextField("0");
    display.setHorizontalAlignment(JTextField.RIGHT);
    display.setEditable(false);
    display.setFont(new Font("Arial", Font.BOLD, 24));
    add(display, BorderLayout.NORTH);

    JPanel panelBotones = new JPanel(new GridLayout(4, 4, 5, 5));

    String[] botones = {
        "7", "8", "9", "/",
        "4", "5", "6", "*",
        "1", "2", "3", "-",
        "0", "=", "C", "+"
    };

    for (String texto : botones) {
        JButton btn = new JButton(texto);
        btn.setFont(new Font("Arial", Font.BOLD, 18));
        btn.addActionListener(crearListener(texto));
        panelBotones.add(btn);
    }

    add(panelBotones, BorderLayout.CENTER);

    pack();
    setLocationRelativeTo(null);
}

    
    private ActionListener crearListener(String texto) {
        return e -> {
            if (texto.matches("[0-9]")) {
                if (nuevaOperacion) {
                    display.setText(texto);
                    nuevaOperacion = false;
                } else {
                    display.setText(display.getText() + texto);
                }
            } else if (texto.matches("[+\\-*/]")) {
                calcular();
                operacion = texto;
                nuevaOperacion = true;
            } else if (texto.equals("=")) {
                calcular();
                operacion = "=";
                nuevaOperacion = true;
            } else if (texto.equals("C")) {
                resultado = 0;
                operacion = "";
                display.setText("0");
                nuevaOperacion = true;
            }
        };
    }
    
    private void calcular(){
        double valor = Double.parseDouble(display.getText());
        
        switch (operacion) {
            case "+": resultado += valor; break;
            case "-": resultado -= valor; break;
            case "*": resultado *= valor; break;
            case "/": resultado = valor == 0 ? 0 : resultado / valor; break;
            default: resultado = valor; break;
        }
        display.setText(String.valueOf(resultado));
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Calculadora_Jemmy().setVisible(true));
    }
}
