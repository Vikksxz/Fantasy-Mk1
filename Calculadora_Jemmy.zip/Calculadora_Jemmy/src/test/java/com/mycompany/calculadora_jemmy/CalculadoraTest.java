package com.mycompany.calculadora_jemmy;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import org.netbeans.jemmy.operators.JButtonOperator;
import org.netbeans.jemmy.operators.JFrameOperator;
import org.netbeans.jemmy.operators.JTextFieldOperator;
import org.junit.jupiter.api.AfterEach;


/**
 *
 * @author george
 */

public class CalculadoraTest {
    private JFrameOperator frame;
    
    @BeforeEach
    public void setUp(){
        Calculadora_Jemmy calc = new Calculadora_Jemmy();
        calc.setVisible(true);
        frame = new JFrameOperator("Calculadora");
    }
    
    @AfterEach
    public void stop(){
        if (frame != null) {
            frame.close();
        }
    }
    
    @Test
    public void testSumaSimple() {
        new JButtonOperator(frame, "1").push();
        new JButtonOperator(frame, "+").push();
        new JButtonOperator(frame, "2").push();
        new JButtonOperator(frame, "=").push();
        
        JTextFieldOperator display = new JTextFieldOperator(frame);
        assertEquals("3.0", display.getText(), "1 + 2 debe ser 3");
    }
    
    @Test
    public void testResta() {
        new JButtonOperator(frame, "5").push();
        new JButtonOperator(frame, "-").push();
        new JButtonOperator(frame, "3").push();
        new JButtonOperator(frame, "=").push();
        
        JTextFieldOperator display = new JTextFieldOperator(frame);
        assertEquals("2.0", display.getText());
    }
    
    @Test
    public void testMultiplicacion() {
        new JButtonOperator(frame, "4").push();
        new JButtonOperator(frame, "*").push();
        new JButtonOperator(frame, "2").push();
        new JButtonOperator(frame, "=").push();
        
        JTextFieldOperator display = new JTextFieldOperator(frame);
        assertEquals("8.0", display.getText());
    }
    
    @Test
    public void testDivision() {
        new JButtonOperator(frame, "8").push();
        new JButtonOperator(frame, "/").push();
        new JButtonOperator(frame, "2").push();
        new JButtonOperator(frame, "=").push();
        
        JTextFieldOperator display = new JTextFieldOperator(frame);
        assertEquals("4.0", display.getText());
    }
    
    @Test
    public void testOperacionCombinada() {
        new JButtonOperator(frame, "2").push();
        new JButtonOperator(frame, "+").push();
        new JButtonOperator(frame, "3").push();
        new JButtonOperator(frame, "*").push();
        new JButtonOperator(frame, "4").push();
        new JButtonOperator(frame, "=").push();
        
        JTextFieldOperator display = new JTextFieldOperator(frame);
        assertNotEquals("14.0", display.getText(), "no se respeta la prioridad de operaciones");
        assertEquals("20.0", display.getText(), "respeta la prioridad");
    }
}
